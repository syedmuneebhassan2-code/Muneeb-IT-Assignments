# Demo: Looping Over Lists

magicians = ["alice", "david", "carolina"]

# Basic for loop
for magician in magicians:
    print(magician)

# Doing more inside the loop
for magician in magicians:
    print(f"{magician.title()}, that was a great trick!")
    print(f"I can't wait to see your next trick, {magician.title()}.\n")

print("Thank you, everyone. That was a great magic show!")

# Indentation matters - this line is outside the loop
for magician in magicians:
    print(magician.upper())
print("Done with the loop")
