# Chapter 4 - Try it Yourself Problems

# ---------------------------------------------------------
# Problem 4-1: Favorite places with a for loop
# ---------------------------------------------------------
places = ["The Grand Canyon", "Niagara Falls", "Yellowstone", "The Statue of Liberty"]
for place in places:
    print(place + " is a nice place to visit")

print()

# ---------------------------------------------------------
# Problem 4-2: Print 90 to 100 inclusive
# ---------------------------------------------------------
# range() stops BEFORE the end number, so I use 101 to include 100
for number in range(90, 101):
    print(number)

print()

# ---------------------------------------------------------
# Problem 4-3: Sum of 100,000 to 1,000,000
# ---------------------------------------------------------
big_numbers = list(range(100000, 1000001))   # 1000001 so that 1,000,000 is included
print("Sum of 100,000 to 1,000,000:", sum(big_numbers))

print()

# ---------------------------------------------------------
# Problem 4-4: 20 numbers in random order, find max and min
# ---------------------------------------------------------
numbers = [47, 12, 89, 3, 66, 31, 95, 24, 58, 7, 73, 40, 18, 82, 29, 61, 5, 90, 36, 51]
print("My list:", numbers)
print("Largest number:", max(numbers))
print("Lowest number:", min(numbers))

print()

# ---------------------------------------------------------
# Problem 4-5: Multiples of 5 between 1 and 100
# ---------------------------------------------------------
# Start at 5, stop before 101, step by 5
multiples_of_five = list(range(5, 101, 5))
print(multiples_of_five)

print()

# ---------------------------------------------------------
# Problem 4-6: Values 20 to 30, doubled with list comprehension
# ---------------------------------------------------------
values = list(range(20, 31))
print("Values 20 to 30:", values)

# List comprehension to double each number
doubled = [value * 2 for value in values]
print("Doubled values:", doubled)

print()

# ---------------------------------------------------------
# Problem 4-7: Slices of the list from problem 4-4
# ---------------------------------------------------------
print("The first 2 values in the list:")
print(numbers[:2])

# Items 5-10 (counting from 1) are at indexes 4 through 9
print("Items 5-10 in the list:")
print(numbers[4:10])

print("The last 4 items in the list:")
print(numbers[-4:])

print()

# ---------------------------------------------------------
# Problem 4-8: Copying a list
# ---------------------------------------------------------
bands = ["Imagine Dragons", "Coldplay", "Linkin Park"]

# [:] makes a real copy (not just another name for the same list)
bands_copy = bands[:]

# Add a band to the ORIGINAL list only
bands.append("Maroon 5")

print("Original list:", bands)
print("Copied list:", bands_copy)

print()

# ---------------------------------------------------------
# Problem 4-9: Tuple of grades, then try to modify it
# ---------------------------------------------------------
grades = ("1st", "2nd", "3rd", "4th", "5th")
print("Grades:", grades)

# Trying to change a value using list syntax - tuples can't be changed,
# so this causes a TypeError. I used try/except so the program keeps running.
try:
    grades[0] = "Kindergarten"
except TypeError as error:
    print("Error: tuples can't be modified ->", error)
