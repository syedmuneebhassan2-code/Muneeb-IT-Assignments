# Demo: Working with Strings

name = "ada lovelace"

# Changing case
print(name.title())
print(name.upper())
print(name.lower())

# Combining strings (concatenation)
first_name = "ada"
last_name = "lovelace"
full_name = first_name + " " + last_name
print(full_name)
print("Hello, " + full_name.title() + "!")

# f-strings
print(f"Hello, {full_name.title()}!")

# Whitespace
language = "  python  "
print("[" + language + "]")
print("[" + language.lstrip() + "]")
print("[" + language.rstrip() + "]")
print("[" + language.strip() + "]")

# Tabs and newlines
print("Languages:\n\tPython\n\tJava\n\tC++")
