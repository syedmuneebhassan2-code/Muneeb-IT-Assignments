# Demo: Working with Numeric Lists and Ranges

# range() stops before the end number
for value in range(1, 5):
    print(value)

# Making a list from range()
numbers = list(range(1, 6))
print(numbers)

# Using a step
even_numbers = list(range(2, 11, 2))
print(even_numbers)

# Squares using a loop
squares = []
for value in range(1, 11):
    squares.append(value ** 2)
print(squares)

# Simple statistics
digits = [1, 2, 3, 4, 5, 6, 7, 8, 9, 0]
print(min(digits))
print(max(digits))
print(sum(digits))

# List comprehension
squares = [value ** 2 for value in range(1, 11)]
print(squares)

# Slicing
players = ["charles", "martina", "michael", "florence", "eli"]
print(players[0:3])
print(players[:4])
print(players[2:])
print(players[-3:])

# Copying a list
my_foods = ["pizza", "falafel", "carrot cake"]
friend_foods = my_foods[:]
my_foods.append("cannoli")
print(my_foods)
print(friend_foods)
