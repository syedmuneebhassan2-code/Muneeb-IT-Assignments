# Chapter 2 - Try it Yourself Problems

# ---------------------------------------------------------
# Problem 2-1: Favorite restaurant, then favorite dish
# ---------------------------------------------------------
favorite = "Olive Garden"
print(favorite)

# Change the value of the same variable to my favorite dish there
favorite = "Chicken Alfredo"
print(favorite)

print()

# ---------------------------------------------------------
# Problem 2-2: Last business + item purchased (concatenation)
# ---------------------------------------------------------
business = "Walmart"
item = "a phone charger"

# Using string concatenation (+) to splice the variables in
print("The last time I went to " + business + ", I purchased " + item + ".")

print()

# ---------------------------------------------------------
# Problem 2-3: Favorite car in lower, upper, and title case
# ---------------------------------------------------------
car = "toyota Camry"
print(car.lower())   # lowercase
print(car.upper())   # UPPERCASE
print(car.title())   # Title Case

print()

# ---------------------------------------------------------
# Problem 2-4: Favorite quote, whitespace, lstrip(), strip()
# ---------------------------------------------------------
quote = "The only way to do great work is to love what you do."

# Add \t\n to the beginning and end using concatenation
quote = "\t\n" + quote + "\t\n"
print("Original quote with whitespace:")
print(quote)

# lstrip() removes whitespace from the LEFT side only
left_stripped = quote.lstrip()
print("After lstrip():")
print(left_stripped)

# strip() removes whitespace from BOTH sides
fully_stripped = quote.strip()
print("After strip():")
print(fully_stripped)

print()

# ---------------------------------------------------------
# Problem 2-5: My own math problem
# ---------------------------------------------------------
result = 25 * 4 + 10   # my math problem: 25 x 4 + 10
print("The result of my math problem is: " + str(result) + ".")
