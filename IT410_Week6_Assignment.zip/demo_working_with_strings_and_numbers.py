# Demo: Working with Strings and Numbers

age = 23

# This would cause a TypeError because you can't add a string and an int:
# message = "Happy " + age + "rd Birthday!"

# Fix: convert the number to a string with str()
message = "Happy " + str(age) + "rd Birthday!"
print(message)

# f-string handles the conversion automatically
print(f"Happy {age}rd Birthday!")

# Converting strings to numbers
price = "19.99"
print(float(price) * 2)

quantity = "3"
print(int(quantity) + 1)

# Mixing in a calculation
total = float(price) * int(quantity)
print("Your total is $" + str(total))
