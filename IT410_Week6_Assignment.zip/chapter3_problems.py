# Chapter 3 - Try it Yourself Problems

# ---------------------------------------------------------
# Problem 3-1: Last 4 books read (no loops allowed)
# ---------------------------------------------------------
books = ["the hunger games", "harry potter and the sorcerer's stone", "the hobbit", "to kill a mockingbird"]

# Printing each one by index, in title case, with no loop
print("I just read: " + books[0].title())
print("I just read: " + books[1].title())
print("I just read: " + books[2].title())
print("I just read: " + books[3].title())

print()

# ---------------------------------------------------------
# Problem 3-2: Top 4 TV shows
# ---------------------------------------------------------
shows = ["Abbott Elementary", "The Bear", "Severance", "Only Murders in the Building"]
print("Starting list:", shows)

# Pretend "Severance" got cancelled - replace it with a new show
shows[2] = "Ted Lasso"
print("After replacing the cancelled show:", shows)

# Add one show using append() (goes to the end)
shows.append("Reservation Dogs")

# Add one show using insert() - NOT first or last position (index 2 is in the middle)
shows.insert(2, "Shrinking")
print("After append() and insert():", shows)

# Remove the last item using pop() and print it
removed = shows.pop()
print("Removed with pop():", removed)

# Use del to remove the first three shows
del shows[0:3]

# Print whatever is left
print("What's left:", shows)

print()

# ---------------------------------------------------------
# Problem 3-3: len(), sort(), sorted(), reverse()
# ---------------------------------------------------------
# My collection: ages of some people
ages = [34, 12, 56, 21, 45, 8]
print("Original list:", ages)

# len() - how many items are in the list
print("Number of items (len):", len(ages))

# sorted() - returns a NEW sorted list, original stays the same
print("Using sorted():", sorted(ages))
print("Original after sorted():", ages)

# sort() - sorts the ORIGINAL list in place
ages.sort()
print("After sort():", ages)

# reverse() - reverses the order of the list in place
ages.reverse()
print("After reverse():", ages)

print()

# ---------------------------------------------------------
# Problem 3-4: Indexing error + commented-out fix
# NOTE: This is last in the file on purpose. The error below
# is intentional and will stop the program when it runs.
# ---------------------------------------------------------
fruits = ["apple", "banana", "cherry"]

# ERROR: the list only has indexes 0, 1, 2, so index 3 doesn't exist
# This raises: IndexError: list index out of range
print(fruits[3])

# FIX: use index 2 to get the last item (or -1, which always gets the last item)
# print(fruits[2])
# print(fruits[-1])
