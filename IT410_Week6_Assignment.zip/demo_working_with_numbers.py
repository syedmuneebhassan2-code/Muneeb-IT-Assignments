# Demo: Working with Numbers

# Basic math
print(2 + 3)
print(3 - 2)
print(2 * 3)
print(3 / 2)

# Exponents
print(3 ** 2)
print(3 ** 3)
print(10 ** 6)

# Order of operations
print(2 + 3 * 4)
print((2 + 3) * 4)

# Floats
print(0.1 + 0.1)
print(2 * 0.5)

# Underscores in large numbers
universe_age = 14_000_000_000
print(universe_age)

# Multiple assignment
x, y, z = 0, 1, 2
print(x, y, z)

# Constants
MAX_CONNECTIONS = 5000
print(MAX_CONNECTIONS)
