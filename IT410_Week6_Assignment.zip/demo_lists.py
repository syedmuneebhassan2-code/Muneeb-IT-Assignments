# Demo: Lists Demonstration

bicycles = ["trek", "cannondale", "redline", "specialized"]
print(bicycles)

# Accessing items by index
print(bicycles[0].title())
print(bicycles[-1])

# Modifying an item
bicycles[0] = "giant"
print(bicycles)

# Adding items
bicycles.append("schwinn")
bicycles.insert(1, "bianchi")
print(bicycles)

# Removing items
del bicycles[0]
print(bicycles)

popped = bicycles.pop()
print(popped)
print(bicycles)

bicycles.remove("redline")
print(bicycles)

# Organizing a list
cars = ["bmw", "audi", "toyota", "subaru"]
cars.sort()
print(cars)
cars.sort(reverse=True)
print(cars)
print(sorted(cars))
cars.reverse()
print(cars)
print(len(cars))
